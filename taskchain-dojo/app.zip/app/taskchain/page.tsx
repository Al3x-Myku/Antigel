"use client";

import React from "react";
import "@copilotkit/react-ui/styles.css";
import "./style.css";
import { CopilotChat } from "@copilotkit/react-ui";

const TaskchainAgenticChat: React.FC = () => {
  return (
    <div
      className="flex justify-center items-center h-screen w-screen bg-slate-950"
      data-testid="background-container"
    >
      <div className="h-[90vh] w-[95vw] md:w-4/5 md:h-4/5 rounded-2xl">
        <CopilotChat
          className="h-full rounded-2xl max-w-6xl mx-auto copilotKitChat"
          labels={{
            initial:
              "Hi, I'm your TaskChain copilot. Tell me your skills & preferences and I'll fetch matching on-chain tasks from the protocol.",
          }}
          suggestions={[
            {
              title: "Match tasks for me",
              message:
                "I know Solidity and Rust, like infra and DeFi, dislike frontend. Suggest 3 matching on-chain tasks and explain why.",
            },
            {
              title: "Only open tasks",
              message:
                "Show me only open/available tasks that fit a junior Solidity dev.",
            },
          ]}
        />
      </div>
    </div>
  );
};

export default TaskchainAgenticChat;